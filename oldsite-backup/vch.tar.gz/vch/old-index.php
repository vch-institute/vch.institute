<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#">
<head>
<meta name="google-site-verification" content="3wGx-1is4FlQX7a34H27lIdM6iLT_2An3XdMInPL4uM" />
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<title>VCH | Vibratory Cosmic Health | Frequencies for The Mind Body Soul, and Cosmos</title>
<meta name="keywords" content=" VCH, V, C, H, Sound Healing, Frequency Healing, Cosmic Vibrations, Sound Awakening, Vibratory Cosmic Health, Electrical, Experiments, Vibration, Music, Waves, Cymatics">
<meta name="description" content="VCH | Vibratory Cosmic Health | Frequencies for The Mind Body Soul, and Cosmos">
<meta name="robots" CONTENT="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta property="og:title" content="VCH | Home Page" />
<meta property="og:type" content="image/jpeg" />
<meta property="og:image:secure_url" content="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg" />
<meta property="og:url" content="https://vibratorycosmichealth.com" />
<meta property="og:image" content="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg" />
<meta property="og:image:width" content="400" />
<meta property="og:image:height" content="300" />
<link rel="stylesheet" type="text/css" href="vch.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<style>
</style><body><div id="wrap">
<?php include("nav.php"); ?>
</br>
<center>
<a href="https://vibratorycosmichealth.com"><img src="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg"></img></a>
</center>




</br><center>
<?php include("body.php"); ?>
<!--
<?php include("lightbox.php"); ?>
-->
</center>
</body>

<!-- FOOTER -->
<div class="container"><center>
<?php include("social.php"); ?>
</center><center>
<?php include("footer.php"); ?>
</div></center></div>

</html>


