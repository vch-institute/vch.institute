<ul>
  <li><a href="https://vibratorycosmichealth.com">Home</a></li>
  <li><a href="https://vibratorycosmichealth.com/about">About VCH</a></li>
  <li><a href="https://facebook.com/vchealth">Facebook</a></li>
  <li class="dropdown">
    <a href="#" class="dropbtn">Partners</a>
    <div class="dropdown-content">
      <a href="http://gongster.com">Gongster</a>
	  <a href="https://harmonicinnerprizes.com">Harmonic Innerprizes</a>
      <a href="http://suspicious0bservers.org">Suspicious0bservers</a>
	  <a href="http://quakewatch.net">QuakeWatch.net</a>
	  <a href="http://spaceweathernews.com">Space Weather News</a>
	  
	  
    </div>
  </li>
   <li class="dropdown">
    <a href="#" class="dropbtn">RESEARCH TOPICS</a>
    <div class="dropdown-content">
      <a href="https://vibratorycosmichealth.com/research">VIDEOS</a>
      <a href="https://vibratorycosmichealth.com/research/index2.php">Chakra's and Endocrine Harmonics</a>
      <a href="https://vibratorycosmichealth.com/research/index3.php">Yelvertons Electrical Experiments</a>
    </div>
  </li>
   <li class="dropdown">
    <a href="#" class="dropbtn">LIBRARY</a>
    <div class="dropdown-content">
      <a href="https://vibratorycosmichealth.com/library/documents">Documents</a>
	  <a href="https://vibratorycosmichealth.com/library/audio">Audio</a>
	  <a href="https://vibratorycosmichealth.com/library/videos">Videos</a>
	  <a href="https://vibratorycosmichealth.com/library/publications">Publications</a>
      
    </div>
  </li>
  <li><a href="mailto:vibratorycosmichealth@gmail.com">Contact</a></li>
  <li><a href="#">Phone:(303)578-6717</a></li>
</ul>

</br></br></br></br>