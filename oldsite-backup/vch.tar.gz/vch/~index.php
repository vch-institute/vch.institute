<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#">
<head>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<title>VCH | Vibratory Cosmic Health | Frequencies for The Mind Body Soul, and Cosmos</title>
<meta name="keywords" content=" VCH, V, C, H, Sound Healing, Frequency Healing, Cosmic Vibrations, Sound Awakening, Vibratory Cosmic Health"
<meta name="description" content="VCH | Vibratory Cosmic Health | Frequencies for The Mind Body Soul, and Cosmos"
<meta http-equiv="content-type" content="text/html;charset=UTF-8">
<meta name="robots" CONTENT="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta property="og:title" content="VCH | Home Page" />
<meta property="og:type" content="image/jpeg" />
<meta property="og:image:secure_url" content="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg" />
<meta property="og:url" content="https://vibratorycosmichealth.com" />
<meta property="og:image" content="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg" />
<meta property="og:image:width" content="400" />
<meta property="og:image:height" content="300" />
</head>



<style>

div.container p {
text-align: center;
font-size: 20px;
font-style: italic;
font-weight: bold;
text-decoration: none;
text-transform: none;
letter-spacing: 2px;
line-height: 25px;
text-indent: 0.1px;
color: #ffffff;
background-color: #000000;
width: 100%;
margin-left:auto;
margin-right:auto;


width: 100%;
}

body {
    background-image: url("https://vibratorycosmichealth.com/images/background.jpg");
	background-repeat: no-repeat;
    background-color: #000000;
	width:100%;
    margin-left:auto;
    margin-right:auto;

}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #9aa7a6;
}
ul {
    position: fixed;
    bottom: 0;
    width: 100%;
}
li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

/* Change the link color to #111 (black) on hover */
li a:hover {
    background-color: #111;
}


.active {
    background-color: #4f4f4f4;
}

 /* Add a gray right border to all list items, except the last item (last-child) */
li {
    border-right: 1px solid #bbb;
}

li:last-child {
    border-right: none;
}

/* Style The Dropdown Button */
.dropbtn {
    background-color: #000000;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;

    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
    display: block;
}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {
    background-color: #000000;
}
</style>





</p></div><?php include("nav.php"); ?>
<div class="dropdown">
  <button class="dropbtn">Founders</button>
  <div class="dropdown-content">
    <a href="https://facebook.com/apostolos.dekatress">Ricky Neff</a>
    <a href="https://www.facebook.com/GongsterGirl">Lisa Gongster</a>
	<a href="#">Call Us +13035786717</a>

  </div>
</div>
</br>
<center>
<img src="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg"></img>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=1711231309144807";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-like" data-href="https://www.facebook.com/VCHealth/" data-layout="standard" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div></center>
<div class="container">

<p>Mission Statement:
<p>Our Goal Is To Provide A Medium For Acoustic, Vibrational, and Frequency Healing.</p><p> As well as the research and documentation of the sciences and forces at work.</p>
<center><img src="https://vibratorycosmichealth.com/images/transformational.jpg"/></img></center>
<p>In the near future the scope and range of our activities</p>
<p> will drastically improve so feel free to make suggestions.</p>

</div>
<div class="container">
<p>Why Sound Healing? Why Vibratory Cosmic Health? Why Does Our Work Help You?</p>
<center>
<img src="https://vibratorycosmichealth.com/images/whychart.jpg" height="900" width="900"></img><p>
</center>
Rather Convincing Data Has Been Revealed In Brain Wave Studies.</p></br>

<p>What Is Sound Healing?</p>

<p>Healing Sound and Vibration practice is done primarily with Gongs, and other healing musical instruments to enable you to relax, reset, feel, be, and belong.</p>
<center><iframe width="750" height="500" src="https://www.youtube.com/embed/aQ-JDNfviDM" frameborder="0" allowfullscreen></iframe></center>
<p>Meditation is one of the ways in which the spiritual man keeps himself awake.
— Thomas Merton</p>
 <p>Sound and music have profound effects on our physiology - awakening the memory of wholeness and entraining the body toward greater harmony and balance.</p>
</div>
<div class="container">
<p>Benefits of a Sound Session:</p>
<center><img src="https://vibratorycosmichealth.com/images/panaramic-gongster.jpg"></img></center>
<p><b>Information from Lisa Gongster.</b>
Sound hydrates the tissue.
Sound helps the body stay more liquid. (Cymatics). </p><center>
<img src="https://vibratorycosmichealth.com/images/2.jpg" height="200"></img><img src="https://vibratorycosmichealth.com/images/3.jpg" height="200"></img></center></br><center><img src="https://vibratorycosmichealth.com/images/1.jpg" height=""></img></center>
Sound work speaks directly to the innate intelligence of the person.</p>
Sound compliments and enhances other mind body therapies.
<p> Sound improves circulation and oxygenation. Sound helps dissolve historically held memories in tissue.</p>
<p>A deeper rest and relaxation is obtained.</p>
<p>A balancing of the electro-magnetic field.</p>


</br></br>
<p>What Sound Is Right For You? What Sound is right for you when?</p>
<p><b>Information from Richard Neff (ALLSTEP.TV and Creation Studios, L.L.C.)</b></p>
<p>Pain is often released back into the ether.</p>
<p>Great benefits in relieving Karmic connections to unwanted resonance frequencies can also be adjusted, or electrically nulled.</p>
<center><img src="/images/GLANDS.jpg"></a></center>
<p>Endocrine systems, basically everywhere in the body there is a major gland centre, your chakras, All have harmonic resonances.</p>
<center><img src="/images/zodiackeys.jpg"></img><img src="/images/zodiac.jpg"></img></center><p>For Research Work of which these charts were made, See the research tab at the main menu.</p>
<p>Every single zodiac has a harmonic resonance. This is much to say, coming from pure Christian Buddhist. I am a student. You are the teacher.</p>
<p>We need participation from all star currents. This electrical experiment, wait, did I just say electrical? I am sorry. </p><p>I intended to say MUSIC! requires all of the 12 zodiacs to participate for this to work. The more the better. Bring your research. This must be done right! If you find a problem with ours. Please, CONTACT US!</p>


</div>

<body>
<center>
</br>

</center>
</body>

<div class="container">
<p>HOSTED & DESIGNED @ <a href="https://allstep.tv">ALLSTEP.TV</a> | All Rights Reserved ® Copyright 2017 © <a href="https://allstep.tv">ALLSTEP.TV and Creation Studios, L.L.C.</a>  </p>
</div>
</br></br></br></br></br></br>
</html>


