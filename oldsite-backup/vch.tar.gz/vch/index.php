<html>
<head>
<title>VCH | Vibratory Cosmic Health | Frequencies for The Mind Body Soul, and Cosmos</title>
<meta name="keywords" content=" VCH, V, C, H, Sound Healing, Frequency Healing, Cosmic Vibrations, Sound Awakening, Vibratory Cosmic Health, Electrical, Experiments, Vibration, Music, Waves, Cymatics">
<meta name="description" content="VCH | Vibratory Cosmic Health | Frequencies for The Mind Body Soul, and Cosmos">
<meta name="robots" CONTENT="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="vch.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<META HTTP-EQUIV=REFRESH CONTENT="0.1; URL=https://github.com/diveyez/vch.institute">
<style>
	  body {
	background-color: black;
	background-size: cover;
	background-repeat: no-repeat;
	max-width: 500px;
	max-height: 500px;
	width: 500px;
	height: 500px;
	position: inherit;
	}
		
	 /* unvisited link */
		a:link {
    color: red;
	}

	/* visited link */
		a:visited {
    color: green;
	}

	/* mouse over link */
	a:hover {
    color: hotpink;
	}

	/* selected link */
	a:active {
    color: blue;
	} 
		.footer {
	color: white;
	font-family: 'Audiowide', cursive;
	margin-top: 100px;
	margin-left: 3px;
	margin-right: 166px;
	margin-bottom: 166px;
	font-size: 25px;
		}
		p1 {
			color: white;
			font-size: 18px;
		}
		
	</style>
	<META HTTP-EQUIV=REFRESH CONTENT="1; URL=https://r2nhosting.com/site/tls/index.php">.
</head>
<!-- FONTS 
    font-family: 'Shadows Into Light Two', cursive;

    font-family: 'Audiowide', cursive;

    font-family: 'Pragati Narrow', sans-serif;

    font-family: 'Caveat', cursive;

    font-family: 'Syncopate', sans-serif;

    font-family: 'Annie Use Your Telescope', cursive;
-->
	
<!-- SPACE FOR MENU  <menu></menu> -->

	<!-- Wrapper?? <div id="wrapper"></div> -->
	
<!-- Body and Heading Stages -->

<body>
<p1>Checking to make sure the connection is secure....</p1>

<!-- Footer -->
<div class="footer">
  <?php 
// No argument required for current year.
// Otherwise, pass start year as a 4-digit value.
function auto_copyright($startYear = null) {
	$thisYear = date('Y');  // get this year as 4-digit value
    if (!is_numeric($startYear)) {
		$year = $thisYear; // use this year as default
	} else {
		$year = intval($startYear);
	}
	if ($year == $thisYear || $year > $thisYear) { // $year cannot be greater than this year - if it is then echo only current year
		echo "&copy; $thisYear"; // display single year
	} else {
		echo "&copy; $year&ndash;$thisYear"; // display range of years
	}   
 } 
 ?>

  <?php auto_copyright(2016);  // 2016 - Current ?>
</div></body>
</html>

</head>
</html>
