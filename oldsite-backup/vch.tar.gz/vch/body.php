<div class="container">

<p>""Meditation is one of the ways in which the spiritual man keeps himself awake."" - Thomas Merton</p>
<p>Sound, Electricity, Frequency and Music; clearly have profound effects on our physiology awakening the memory of wholeness and entraining the body toward greater harmony and balance.</p>
<p><iframe width="476" height="267" src="https://www.youtube.com/embed/n-yCYAn938c" frameborder="0" allowfullscreen></iframe></p>
</div>
<div class="container">
<center><a href="https://facebook.com/vchealth"><img src="https://vibratorycosmichealth.com/images/transformational.jpg" width="900px"/></img></a></center>
</div>
