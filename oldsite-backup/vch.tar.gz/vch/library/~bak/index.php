<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#">
<head>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<title>VCH - OPEN ACCESS LIBRARY | Vibratory Cosmic Health </title>
<meta name="keywords" content=" VCH, V, C, H, Sound Healing, Frequency Healing, Cosmic Vibrations, Sound Awakening, Vibratory Cosmic Health, Research, LIBRARY"
<meta name="description" content="VCH - LIBRARY| Vibratory Cosmic Health | OPEN ACCESS"
<meta http-equiv="content-type" content="text/html;charset=UTF-8">
<meta name="robots" CONTENT="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta property="og:title" content="VCH - LIBRARY" />
<meta property="og:type" content="image/jpeg" />
<meta property="og:image:secure_url" content="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg" />
<meta property="og:url" content="https://vibratorycosmichealth.com" />
<meta property="og:image" content="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg" />
<meta property="og:image:width" content="400" />
<meta property="og:image:height" content="300" />
<link rel="stylesheet" type="text/css" href="../vch.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>



<style>

</style>
<div id="wrap">
<?php include("../nav.php"); ?>
<center>
<a href="https://vibratorycosmichealth.com"><img src="https://vibratorycosmichealth.com/images/VCH-HEADER.jpg"></img></a></center>
<div class="container"><center>

<p>

</p>
</center>
</div>
<script>
  (function() {
    var cx = '007739762316212681017:cfodjlclrq0';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<gcse:search></gcse:search>
<body>
<center>
</br><div class="container">
<p>ALL RESEARCH WILL BE CREDITED TO THEIR ORIGINAL SOURCES. AT A LATER DATE A CATALOG SYSTEM WILL EXIST.</p></div>
</center>
</body>

<div class="container">
<?php include("../footer.php"); ?>
</div></div>
</html>


